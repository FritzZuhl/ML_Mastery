# check version number
import xgboost
print(xgboost.__version__)