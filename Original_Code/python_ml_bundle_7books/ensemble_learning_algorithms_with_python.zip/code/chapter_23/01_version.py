# check xgboost library version
import xgboost
print(xgboost.__version__)